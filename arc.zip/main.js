const express = require('express');
const fs = require('fs');
const bodyParser = require('body-parser');
const path = require('path');
const xlsx = require('xlsx');
const app = express();

app.use(bodyParser.json());
app.use(bodyParser.urlencoded({
    limit: '150mb',
    extended: false,
}));

app.get('/', function(req,res) {
    res.sendFile(__dirname + "/public/main.html");
    const dir = __dirname + "/public/test/inventory.json"
    const dataBuffer = fs.readFileSync(dir)
    const dataJSON = JSON.parse(dataBuffer)
    const sheetnames = Object.keys(dataJSON);
    //console.log(dataJSON)
    //console.log(sheetnames)
    let i = sheetnames.length;
    let resData;
    //console.log(i)
    const workbook = xlsx.utils.book_new();
    while (i--) {
        const sheetname = sheetnames[i];
        //console.log(sheetnames[i])
        //console.log(dataJSON[sheetnames[i]])
        worksheet = xlsx.utils.json_to_sheet(dataJSON[sheetnames[i]]); //npo
        xlsx.utils.book_append_sheet(workbook, worksheet, sheetnames[i]);
    }
    xlsx.writeFile(workbook, path.join(__dirname, 'array_to_sheet_result.xlsx'));
})

// localhost:3000/main 브라우저에 res.sendFile() 내부의 파일이 띄워진다.
app.get('/406', function(req,res){
    res.sendFile(__dirname + "/public/storages/storages.html");
  })

app.get('/B05', function(req,res){
    res.sendFile(__dirname + "/public/storages/storages.html");
  })

app.get('/B09-3', function(req,res){
    res.sendFile(__dirname + "/public/storages/storages.html");
})

app.get('/action_page.php', function(req,res){
    console.log(req.query);
    res.sendFile(__dirname + "/public/main.html");
})

app.get('/406/:id', function(req,res){
  res.sendFile(__dirname + "/public/test/inventory.html");
})
app.get('/B05/:id', function(req,res){
  res.sendFile(__dirname + "/public/test/inventory.html");
})
app.get('/B09-3/:id', function(req,res){
  res.sendFile(__dirname + "/public/test/inventory.html");
})

app.get('/search', function(req,res){
  res.sendFile(__dirname + "/public/searching/searching.html");
})


app.listen(3000, function(){
  console.log('Listening at 3000');
})



app.use(express.static('public'));