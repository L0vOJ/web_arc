# HERoEHS-Inventory_Control_Web
HERoEHS/Inventory_Control_Web

<재고 목록 제작 페이지 참고 사이트>

 - https://qh5944.tistory.com/103

<구현 완료>
 - 검색 기능(일반 검색, 상세 검색) 구현 완료
 - 물품 수량 변경 gui 및 물품 정보 수정 GUI 구현 완료 (searching.html이랑 inventory.html 두군데에 기능이 있음)
 - 물품 추가 gui 구현 완료 (main.html, storages.html, searching.html, inventory.html 총 4파일에 기능이 있음)
 - 물품 정보 수정이나 추가 기능은 popup창에서 이루어짐 (해당 팝업창은 코드에 주석으로 위치 표기됨) -> form을 활용하면 될려나?

<앞으로 해야할일>

 - 페이지네이션
 - 박스 버튼 위치 변경
 - 디자인



 *현재 데이터 json파일 위치: public/test/inventory.json

 *json 파일을 사용하는 html 파일: searching.html, inventory.html
